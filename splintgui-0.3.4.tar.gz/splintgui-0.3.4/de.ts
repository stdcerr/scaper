<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>FILL YOUR LANGUAGE NAME HERE</source>
      <translation>Christoph Thielecke</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>MainWindow</source>
      <translation>Hauptfenster</translation>
    </message>
    <message>
      <source>Splint options</source>
      <translation>Splint-Optionen</translation>
    </message>
    <message>
      <source>warnposix</source>
      <translation>warnposix</translation>
    </message>
    <message>
      <source>preproc</source>
      <translation>preproc</translation>
    </message>
    <message>
      <source>posixstrictlib</source>
      <translation>posixstrictlib</translation>
    </message>
    <message>
      <source>posixlib</source>
      <translation>posixlib</translation>
    </message>
    <message>
      <source>retvalint</source>
      <translation>retvalint</translation>
    </message>
    <message>
      <source>compdef</source>
      <translation>compdef</translation>
    </message>
    <message>
      <source>usedef</source>
      <translation>usedef</translation>
    </message>
    <message>
      <source>unrecog</source>
      <translation>unrecog</translation>
    </message>
    <message>
      <source>exportlocal</source>
      <translation>exportlocal</translation>
    </message>
    <message>
      <source>matchanyintegral</source>
      <translation>matchanyintegral</translation>
    </message>
    <message>
      <source>imptype</source>
      <translation>imptype</translation>
    </message>
    <message>
      <source>unixlib</source>
      <translation>unixlib</translation>
    </message>
    <message>
      <source>ptrnegate</source>
      <translation>ptrnegate</translation>
    </message>
    <message>
      <source>bufferoverflowhigh</source>
      <translation>bufferoverflowhigh</translation>
    </message>
    <message>
      <source>&lt;b>checked means +, unchecked -&lt;/b></source>
      <translation>&lt;b>aktiviert heißt +, deaktiviert heißt -&lt;/b></translation>
    </message>
    <message>
      <source>predboolothers</source>
      <translation>predboolothers</translation>
    </message>
    <message>
      <source>varuse</source>
      <translation>varuse</translation>
    </message>
    <message>
      <source>type</source>
      <translation>type</translation>
    </message>
    <message>
      <source>mayaliasunique</source>
      <translation>mayaliasunique</translation>
    </message>
    <message>
      <source>boolops</source>
      <translation>boolops</translation>
    </message>
    <message>
      <source>branchstate</source>
      <translation>branchstate</translation>
    </message>
    <message>
      <source>nullpass</source>
      <translation>nullpass</translation>
    </message>
    <message>
      <source>nullderef</source>
      <translation>nullderef</translation>
    </message>
    <message>
      <source>Files:</source>
      <translation>Dateien:</translation>
    </message>
    <message>
      <source>Choose...</source>
      <translation>Auswählen...</translation>
    </message>
    <message>
      <source>Check!</source>
      <translation>Prüfen!</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Datei</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Hilfe</translation>
    </message>
    <message>
      <source>Quit</source>
      <translation>Beenden</translation>
    </message>
    <message>
      <source>AboutQt</source>
      <translation>Über Qt</translation>
    </message>
    <message>
      <source>Path to splint:</source>
      <translation>Pfad zu splint:</translation>
    </message>
    <message>
      <source>retvalother</source>
      <translation>retvalother</translation>
    </message>
    <message>
      <source>Check mode</source>
      <translation>Prüfmodus</translation>
    </message>
    <message>
      <source>weak</source>
      <translation>schwach</translation>
    </message>
    <message>
      <source>standard</source>
      <translation>normal</translation>
    </message>
    <message>
      <source>checks</source>
      <translation>intensiv</translation>
    </message>
    <message>
      <source>strict</source>
      <translation>strikt</translation>
    </message>
    <message>
      <source>nullret</source>
      <translation>nullret</translation>
    </message>
    <message>
      <source>formattype</source>
      <translation>formattype</translation>
    </message>
    <message>
      <source>onlytrans</source>
      <translation>onlytrans</translation>
    </message>
    <message>
      <source>mustfreefresh</source>
      <translation>mustfreefresh</translation>
    </message>
    <message>
      <source>Check</source>
      <translation>Prüfen</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Optionen</translation>
    </message>
    <message>
      <source>globs</source>
      <translation>globs</translation>
    </message>
    <message>
      <source>namechecks</source>
      <translation>namechecks</translation>
    </message>
    <message>
      <source>isoreserved</source>
      <translation>isoreserved</translation>
    </message>
    <message>
      <source>isolib</source>
      <translation>isolib</translation>
    </message>
    <message>
      <source>exportfcn</source>
      <translation>exportfcn</translation>
    </message>
    <message>
      <source>gnuextensions</source>
      <translation>gnuextensions</translation>
    </message>
    <message>
      <source>paramuse</source>
      <translation>paramuse</translation>
    </message>
    <message>
      <source>Compiler options</source>
      <translation>Compileroptionen</translation>
    </message>
    <message>
      <source>Include dirs (e.g. -I&lt;dir1> -I&lt;dir2>:</source>
      <translation>Include-Verzeichnisse (z.B. -I&lt;dir1> -I&lt;dir2>:</translation>
    </message>
    <message>
      <source>Defines (e.g. -DDEBUG=1):</source>
      <translation>Defines (z.B. -DDEBUG=1):</translation>
    </message>
    <message>
      <source>exportheader</source>
      <translation>exportheader</translation>
    </message>
    <message>
      <source>declundef</source>
      <translation>declundef</translation>
    </message>
    <message>
      <source>temptrans</source>
      <translation>temptrans</translation>
    </message>
    <message>
      <source>trytorecover</source>
      <translation>trytorecover</translation>
    </message>
    <message>
      <source>nullassign</source>
      <translation>nullassign</translation>
    </message>
    <message>
      <source>About SplintGUI</source>
      <translation>Über Splint-GUI</translation>
    </message>
    <message>
      <source>formatconst</source>
      <translation>formatconst</translation>
    </message>
    <message>
      <source>readonlytrans</source>
      <translation>readonlytrans</translation>
    </message>
    <message>
      <source>noeffect</source>
      <translation>noeffect</translation>
    </message>
    <message>
      <source>globstate</source>
      <translation>globstate</translation>
    </message>
    <message>
      <source>compdestroy</source>
      <translation>compdestroy</translation>
    </message>
  </context>
  <context>
    <name>SplintGui</name>
    <message>
      <source>Open File</source>
      <translation>Datei öffnen</translation>
    </message>
    <message>
      <source>C/C++ files (*.c *.cpp)</source>
      <translation>C/C++-Dateien (*.c *.cpp)</translation>
    </message>
    <message>
      <source>Splint GUI v</source>
      <translation>Splint-Oberfläche v</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Version</translation>
    </message>
    <message>
      <source>License:</source>
      <translation>Lizenz:</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>User settings file found at:</source>
      <translation>Benutzereinstellungen gefunden bei:</translation>
    </message>
    <message>
      <source>User settings file not found.</source>
      <translation>Benutzereinstellungen-Datei nicht gefunden.</translation>
    </message>
    <message>
      <source>User settings file could not written to:</source>
      <translation>Benutzereinstellungendatei konnte nicht geschrieben werden nach:</translation>
    </message>
    <message>
      <source>SplintGui</source>
      <translation>Splint-Oberfläche</translation>
    </message>
    <message>
      <source>command:</source>
      <translation>Kommando:</translation>
    </message>
    <message>
      <source>Homepage:</source>
      <translation>Homepage:</translation>
    </message>
    <message>
      <source>Feedback:</source>
      <translation>Kontakt:</translation>
    </message>
    <message>
      <source>* All files</source>
      <translation>* Alle Dateien</translation>
    </message>
    <message>
      <source>processing file:</source>
      <translation>Datei wird verarbeitet:</translation>
    </message>
    <message>
      <source>Checking finished</source>
      <translation>Überprüfung abgeschlossen</translation>
    </message>
    <message>
      <source>Running from dir:</source>
      <translation>Starte in Verzeichnis:</translation>
    </message>
    <message>
      <source>No splint</source>
      <translation>Kein Splint</translation>
    </message>
    <message>
      <source>Splint could not found. Please check the path:</source>
      <translation>Split konnte nicht gefunden werden. Bitte überprüfen Sie den Pfad:</translation>
    </message>
  </context>
</TS>
